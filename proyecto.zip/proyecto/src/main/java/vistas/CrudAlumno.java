/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas;

import clasesjava.Alumno;
import clasesjava.AlumnoDAO;
import clasesjava.VehiculoDAO;
import clasesjava.VehiculoHistorialDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CrudAlumno extends JFrame {
    private final JTable tabla;
    private final DefaultTableModel modelo;
    private final JTextField txtBuscar;

    public CrudAlumno() {
        setTitle("CRUD Alumno");
        setSize(900, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        modelo = new DefaultTableModel(new Object[]{
            "ID Persona", "Nombre", "Apellido P", "Matrícula", "Semestre"
        }, 0);
        tabla = new JTable(modelo);
        JScrollPane sp = new JScrollPane(tabla);

        JPanel top = new JPanel(new BorderLayout());
        txtBuscar = new JTextField();
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscar());
        top.add(txtBuscar, BorderLayout.CENTER);
        top.add(btnBuscar, BorderLayout.EAST);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCrear = new JButton("Crear");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnHistorial = new JButton("Historial Vehículos");
        JButton btnRefresh = new JButton("Refrescar");

        btnCrear.addActionListener(e -> crear());
        btnEditar.addActionListener(e -> editar());
        btnEliminar.addActionListener(e -> eliminar());
        btnHistorial.addActionListener(e -> historial());
        btnRefresh.addActionListener(e -> cargar());

        acciones.add(btnCrear); acciones.add(btnEditar); acciones.add(btnEliminar);
        acciones.add(btnHistorial); acciones.add(btnRefresh);

        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);
        add(acciones, BorderLayout.SOUTH);

        cargar();
    }

    private void cargar() {
        modelo.setRowCount(0);
        List<Alumno> alumnos = AlumnoDAO.listarTodos();
        for (Alumno a : alumnos) {
            modelo.addRow(new Object[]{ a.getIdPersona(), a.getNombre(), a.getApellido(),
                                        a.getNumeroControl(), a.getSemestre() });
        }
    }

    private Integer idSeleccionado() {
        int row = tabla.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Selecciona un registro"); return null; }
        return (Integer) modelo.getValueAt(row, 0);
    }

    private void buscar() {
        String t = txtBuscar.getText().trim();
        modelo.setRowCount(0);
        for (Alumno a : AlumnoDAO.buscar(t)) {
            modelo.addRow(new Object[]{ a.getIdPersona(), a.getNombre(), a.getApellido(),
                                        a.getNumeroControl(), a.getSemestre() });
        }
    }

    private void crear() {
        try {
            String nombre = JOptionPane.showInputDialog(this, "Nombre:");
            String apP = JOptionPane.showInputDialog(this, "Apellido Paterno:");
            String apM = JOptionPane.showInputDialog(this, "Apellido Materno (opcional):");
            String tel = JOptionPane.showInputDialog(this, "Teléfono (opcional):");

            String matricula = JOptionPane.showInputDialog(this, "Matrícula:");
            String semestre = JOptionPane.showInputDialog(this, "Semestre (1-12):");
            String estado = JOptionPane.showInputDialog(this, "Estado (opcional):");
            String desc = JOptionPane.showInputDialog(this, "Descripción (opcional):");

            Alumno a = new Alumno(0, nombre, apP, matricula, /* carrera */ "", Integer.parseInt(semestre));
            if (AlumnoDAO.crear(a, apM, tel, estado, desc)) {
                JOptionPane.showMessageDialog(this, "Alumno creado");
                cargar();
            } else JOptionPane.showMessageDialog(this, "No se pudo crear");
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
    }

    private void editar() {
        Integer id = idSeleccionado(); if (id == null) return;
        Alumno a = AlumnoDAO.obtenerPorId(id);
        if (a == null) { JOptionPane.showMessageDialog(this, "No encontrado"); return; }

        try {
            String nombre = JOptionPane.showInputDialog(this, "Nombre:", a.getNombre());
            String apP = JOptionPane.showInputDialog(this, "Apellido Paterno:", a.getApellido());
            String apM = JOptionPane.showInputDialog(this, "Apellido Materno (opcional):", "");
            String tel = JOptionPane.showInputDialog(this, "Teléfono (opcional):", "");

            String matricula = JOptionPane.showInputDialog(this, "Matrícula:", a.getNumeroControl());
            String semestre = JOptionPane.showInputDialog(this, "Semestre:", a.getSemestre());
            String estado = JOptionPane.showInputDialog(this, "Estado (opcional):", "");
            String desc = JOptionPane.showInputDialog(this, "Descripción (opcional):", "");

            a = new Alumno(id, nombre, apP, matricula, "", Integer.parseInt(semestre));
            if (AlumnoDAO.actualizar(a, apM, tel, estado, desc)) {
                JOptionPane.showMessageDialog(this, "Actualizado");
                cargar();
            } else JOptionPane.showMessageDialog(this, "No se pudo actualizar");
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
    }

    private void eliminar() {
        Integer id = idSeleccionado(); if (id == null) return;
        int ok = JOptionPane.showConfirmDialog(this, "¿Eliminar?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            if (AlumnoDAO.eliminar(id)) { JOptionPane.showMessageDialog(this, "Eliminado"); cargar(); }
            else JOptionPane.showMessageDialog(this, "No se pudo eliminar");
        }
    }

    private void historial() {
        Integer id = idSeleccionado(); if (id == null) return;
        List<VehiculoHistorialDTO> items = VehiculoDAO.historialPorPersona(id);
        StringBuilder sb = new StringBuilder("Historial Vehículos de persona #" + id + ":\n\n");
        for (VehiculoHistorialDTO it : items) {
            sb.append("Vehiculo ").append(it.idVehiculo)
              .append(" | Placa ").append(it.placa)
              .append(" | Entrada ").append(it.horaEnt)
              .append(" | Salida ").append(it.horaSalida)
              .append(" | Espacio ").append(it.idEspacio).append("\n");
        }
        JOptionPane.showMessageDialog(this, sb.length() == 0 ? "Sin registros" : sb.toString());
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new CrudAlumno().setVisible(true)); }
}
