/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas;

import clasesjava.Maestro;
import clasesjava.MaestroDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CrudMaestro extends JFrame {
    private final JTable tabla;
    private final DefaultTableModel modelo;
    private final JTextField txtBuscar;

    public CrudMaestro() {
        setTitle("CRUD Maestro");
        setSize(800, 480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        modelo = new DefaultTableModel(new Object[]{
            "ID Persona", "Nombre", "Apellido P", "No. Empleado"
        }, 0);
        tabla = new JTable(modelo);
        JScrollPane sp = new JScrollPane(tabla);

        JPanel top = new JPanel(new BorderLayout());
        txtBuscar = new JTextField();
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscar());
        top.add(txtBuscar, BorderLayout.CENTER);
        top.add(btnBuscar, BorderLayout.EAST);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnCrear = new JButton("Crear");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnRefresh = new JButton("Refrescar");

        btnCrear.addActionListener(e -> crear());
        btnEditar.addActionListener(e -> editar());
        btnEliminar.addActionListener(e -> eliminar());
        btnRefresh.addActionListener(e -> cargar());

        acciones.add(btnCrear); acciones.add(btnEditar); acciones.add(btnEliminar); acciones.add(btnRefresh);

        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);
        add(acciones, BorderLayout.SOUTH);

        cargar();
    }

    private void cargar() {
        modelo.setRowCount(0);
        List<Maestro> maestros = MaestroDAO.listarTodos();
        for (Maestro m : maestros) {
            modelo.addRow(new Object[]{ m.getIdPersona(), m.getNombre(), m.getApellido(), m.getClaveEmpleado() });
        }
    }

    private Integer idSeleccionado() {
        int row = tabla.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Selecciona un registro"); return null; }
        return (Integer) modelo.getValueAt(row, 0);
    }

    private void buscar() {
        String t = txtBuscar.getText().trim();
        modelo.setRowCount(0);
        for (Maestro m : MaestroDAO.buscar(t)) {
            modelo.addRow(new Object[]{ m.getIdPersona(), m.getNombre(), m.getApellido(), m.getClaveEmpleado() });
        }
    }

    private void crear() {
        try {
            String nombre = JOptionPane.showInputDialog(this, "Nombre:");
            String apP = JOptionPane.showInputDialog(this, "Apellido Paterno:");
            String apM = JOptionPane.showInputDialog(this, "Apellido Materno (opcional):");
            String tel = JOptionPane.showInputDialog(this, "Teléfono (opcional):");
            String noEmp = JOptionPane.showInputDialog(this, "Número de empleado:");

            Maestro m = new Maestro(0, nombre, apP, Integer.parseInt(noEmp), /* depto en POJO */ "");
            if (MaestroDAO.crear(m, apM, tel)) {
                JOptionPane.showMessageDialog(this, "Maestro creado");
                cargar();
            } else JOptionPane.showMessageDialog(this, "No se pudo crear");
        } catch (HeadlessException | NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
    }

    private void editar() {
        Integer id = idSeleccionado(); if (id == null) return;
        Maestro m = MaestroDAO.obtenerPorId(id);
        if (m == null) { JOptionPane.showMessageDialog(this, "No encontrado"); return; }

        try {
            String nombre = JOptionPane.showInputDialog(this, "Nombre:", m.getNombre());
            String apP = JOptionPane.showInputDialog(this, "Apellido Paterno:", m.getApellido());
            String apM = JOptionPane.showInputDialog(this, "Apellido Materno (opcional):", "");
            String tel = JOptionPane.showInputDialog(this, "Teléfono (opcional):", "");
            String noEmp = JOptionPane.showInputDialog(this, "Número de empleado:", m.getClaveEmpleado());

            m = new Maestro(id, nombre, apP, Integer.parseInt(noEmp), "");
            if (MaestroDAO.actualizar(m, apM, tel)) {
                JOptionPane.showMessageDialog(this, "Actualizado");
                cargar();
            } else JOptionPane.showMessageDialog(this, "No se pudo actualizar");
        } catch (HeadlessException | NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
    }

    private void eliminar() {
        Integer id = idSeleccionado(); if (id == null) return;
        int ok = JOptionPane.showConfirmDialog(this, "¿Eliminar?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            if (MaestroDAO.eliminar(id)) { JOptionPane.showMessageDialog(this, "Eliminado"); cargar(); }
            else JOptionPane.showMessageDialog(this, "No se pudo eliminar");
        }
    }

    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new CrudMaestro().setVisible(true)); }
}

