/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesjava;

/**
 *
 * @author Carlo
 */
public class Auto extends Vehiculo {
    private String tipoAuto;

    // Constructor
    public Auto(String placa, String marca, String modelo, Persona propietario, String tipoAuto) {
        super(placa, marca, modelo, propietario);
        this.tipoAuto = tipoAuto;
    }

    // Getter y Setter
    public String getTipoAuto() {
        return tipoAuto;
    }

    public void setTipoAuto(String tipoAuto) {
        this.tipoAuto = tipoAuto;
    }

    @Override
    public String toString() {
        return "Auto{" +
                "placa='" + getPlaca() + '\'' +
                ", marca='" + getMarca() + '\'' +
                ", modelo='" + getModelo() + '\'' +
                ", tipoAuto='" + tipoAuto + '\'' +
                '}';
    }
}
