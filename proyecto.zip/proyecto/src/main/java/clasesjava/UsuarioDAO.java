package clasesjava;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UsuarioDAO {
    
    public static boolean crearUsuario(String nombre, String apellidoPaterno, String apellidoMaterno, 
                                     String telefono, String email, String password, int idRol) {
        String sql = "INSERT INTO Usuario (nombre, apellido_paterno, apellido_materno, telefono, correo, contraseña) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
        String sqlRol = "INSERT INTO Usuario_Rol (id_usuario, id_rol) VALUES (?, ?)";
        
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
             PreparedStatement pstmtRol = conn.prepareStatement(sqlRol)) {
            
            // Insertar usuario
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellidoPaterno);
            pstmt.setString(3, apellidoMaterno);
            pstmt.setString(4, telefono);
            pstmt.setString(5, email);
            pstmt.setString(6, password); // En producción, esto debería estar encriptado
            
            int filasAfectadas = pstmt.executeUpdate();
            
            if (filasAfectadas > 0) {
                // Obtener el ID del usuario recién insertado
                ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int idUsuario = generatedKeys.getInt(1);
                    
                    // Asignar rol al usuario
                    pstmtRol.setInt(1, idUsuario);
                    pstmtRol.setInt(2, idRol);
                    pstmtRol.executeUpdate();
                    
                    return true;
                }
            }
            return false;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al crear usuario: " + e.getMessage(),
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public static boolean existeEmail(String email) {
        String sql = "SELECT COUNT(*) FROM Usuario WHERE correo = ?";
        
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
            
        } catch (SQLException e) {
            return false;
        }
    }
}