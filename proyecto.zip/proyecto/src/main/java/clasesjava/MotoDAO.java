package clasesjava;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MotoDAO {

    // INSERTAR MOTO
    public static boolean insertarMoto(int idVehiculo, String tipoMoto) {
        String sql = "INSERT INTO moto (id_vehiculo, tipo_moto) VALUES (?, ?)";
        try (Connection con = ConexionDB.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVehiculo);
            ps.setString(2, tipoMoto);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // OBTENER MOTO POR ID VEHÍCULO
    public static Moto obtenerPorIdVehiculo(int idVehiculo) {
        String sql = "SELECT m.id_vehiculo, m.tipo_moto, v.placa, v.marca, v.modelo, v.id_persona " +
                     "FROM moto m JOIN vehiculo v ON m.id_vehiculo = v.id_vehiculo " +
                     "WHERE m.id_vehiculo = ?";
        try (Connection con = ConexionDB.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVehiculo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Moto(
                        rs.getInt("id_vehiculo"),
                        rs.getString("placa"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getInt("id_persona"),
                        rs.getString("tipo_moto")
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // LISTAR TODAS LAS MOTOS
    public static List<Moto> listarTodas() {
        List<Moto> lista = new ArrayList<>();
        String sql = "SELECT m.id_vehiculo, m.tipo_moto, v.placa, v.marca, v.modelo, v.id_persona " +
                     "FROM moto m JOIN vehiculo v ON m.id_vehiculo = v.id_vehiculo " +
                     "ORDER BY v.placa";
        try (Connection con = ConexionDB.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Moto(
                    rs.getInt("id_vehiculo"),
                    rs.getString("placa"),
                    rs.getString("marca"),
                    rs.getString("modelo"),
                    rs.getInt("id_persona"),
                    rs.getString("tipo_moto")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ELIMINAR MOTO POR ID VEHÍCULO
    public static boolean eliminarMoto(int idVehiculo) {
        String sql = "DELETE FROM moto WHERE id_vehiculo = ?";
        try (Connection con = ConexionDB.conectar(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVehiculo);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
