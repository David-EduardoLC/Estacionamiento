/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesjava;

/**
 *
 * @author Carlo
 */
public class Vehiculo {
    private String placa;
    private String marca;
    private String modelo;
    private Persona propietario;
    
    public Vehiculo(String placa, String marca, String modelo, Persona propietario) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.propietario = propietario;
    }
    
    public String getTipoPropietario() {
        return propietario.getClass().getSimpleName();
    }
    
    public String getPlaca() {
        return placa;
    }
    public void setPlaca(String placa) { 
        this.placa = placa; 
    }
    public String getMarca() {
        return marca; 
    }
    public void setMarca(String marca) {
        this.marca = marca; 
    }
    public String getModelo() { 
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo; 
    }
    public Persona getPropietario() {
        return propietario; 
    }
    public void setPropietario(Persona propietario) {
        this.propietario = propietario; 
    }
     @Override
    public String toString() {
        return "Vehiculo{" +
                "placa='" + placa + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                '}';
    }
}
    

