package clasesjava;

public class Main {
    public static void main(String[] args) {
        // Probar conexión primero
        System.out.println(" Probando conexión a la base de datos...");
        if (ConexionDB.conectar() == null) {
            System.out.println("❌ No se puede continuar sin conexión a la BD");
            return;
        }

        RegistroDAO registroDAO = new RegistroDAO();
        ReporteDAO reporteDAO = new ReporteDAO();

        System.out.println("\n" + "=".repeat(50));
        System.out.println(" PRUEBAS COMPLETAS DEL SISTEMA DE ESTACIONAMIENTO");
        System.out.println("=".repeat(50));

        // ==================== REGISTROS ====================
        System.out.println("\n 1. CREANDO NUEVOS REGISTROS:");
        System.out.println("-".repeat(40));
        
        // Crear registros de entrada
        registroDAO.crearRegistro("08:00", 1, 1);     // Vehículo 1 en Espacio 1
        registroDAO.crearRegistro("09:15", 1, 2);     // Vehículo 1 en Espacio 2
        registroDAO.crearRegistro("10:30", 1, 1);     // Vehículo 1 en Espacio 1

        System.out.println("\n 2. ACTUALIZANDO SALIDAS:");
        System.out.println("-".repeat(40));
        
        // Actualizar salidas
        registroDAO.actualizarRegistro(1, "12:30");   // Salida del registro 1
        registroDAO.actualizarRegistro(2, "14:45");   // Salida del registro 2

        System.out.println("\n 3. LISTANDO TODOS LOS REGISTROS:");
        System.out.println("-".repeat(40));
        
        // Leer todos los registros
        registroDAO.leerRegistros().forEach(System.out::println);

        // ==================== REPORTES ====================
        System.out.println("\n\n 4. CREANDO REPORTES:");
        System.out.println("-".repeat(40));
        
        // Crear reportes
        reporteDAO.crearReporte("Vehículo estacionado incorrectamente", "2025-09-18", "Abierto", 1);
        reporteDAO.crearReporte("Tiempo de estacionamiento excedido", "2025-09-18", "En revisión", 2);
        reporteDAO.crearReporte("Pago pendiente", "2025-09-19", "Abierto", 3);

        System.out.println("\n 5. ACTUALIZANDO ESTATUS DE REPORTES:");
        System.out.println("-".repeat(40));
        
        // Actualizar reportes
        reporteDAO.actualizarReporte(1, "Cerrado");
        reporteDAO.actualizarReporte(2, "Resuelto");

        System.out.println("\n 6. LISTANDO TODOS LOS REPORTES:");
        System.out.println("-".repeat(40));
        
        // Leer todos los reportes
        reporteDAO.leerReportes().forEach(System.out::println);

        // ==================== ELIMINACIONES ====================
        System.out.println("\n\n️  7. PRUEBAS DE ELIMINACIÓN:");
        System.out.println("-".repeat(40));
        
        // Eliminar algunos registros (descomenta para probar)
        // registroDAO.eliminarRegistro(5);
        // reporteDAO.eliminarReporte(3);

        System.out.println("\n" + "=".repeat(50));
        System.out.println("✅ PRUEBAS COMPLETADAS EXITOSAMENTE");
        System.out.println("=".repeat(50));
        
        // Mostrar estado final
        System.out.println("\n ESTADO FINAL DE REGISTROS:");
        System.out.println("-".repeat(40));
        registroDAO.leerRegistros().forEach(System.out::println);
        
        System.out.println("\n ESTADO FINAL DE REPORTES:");
        System.out.println("-".repeat(40));
        reporteDAO.leerReportes().forEach(System.out::println);
    }
}