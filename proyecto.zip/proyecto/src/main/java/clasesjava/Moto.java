/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesjava;

/**
 *
 * @author Carlo
 */
public class Moto extends Vehiculo {
    private String tipoMoto;

    // Constructor
    public Moto(String placa, String marca, String modelo, Persona propietario, String tipoMoto) {
        super(placa, marca, modelo, propietario);
        this.tipoMoto = tipoMoto;
    }

    public String getTipoMoto() {
        return tipoMoto;
    }

    public void setTipoMoto(String tipoMoto) {
        this.tipoMoto = tipoMoto;
    }

    @Override
    public String toString() {
        return "Moto{" +
                "placa='" + getPlaca() + '\'' +
                ", marca='" + getMarca() + '\'' +
                ", modelo='" + getModelo() + '\'' +
                ", tipoMoto='" + tipoMoto + '\'' +
                '}';
    }
}
