package clasesjava;

/**
 * Clase que representa la tabla 'carro' en la base de datos.
 * Hereda de Vehiculo y agrega el campo 'tipoAuto'.
 */
public class Carro extends Vehiculo {
    private String tipoAuto;

    // Constructor completo con ID (para consultas desde la BD)
    public Carro(int idVehiculo, String placa, String marca, String modelo, int idPersona, String tipoAuto) {
        super(idVehiculo, placa, marca, modelo, idPersona);
        this.tipoAuto = tipoAuto;
    }

    // Constructor sin ID (para inserciones nuevas)
    public Carro(String placa, String marca, String modelo, int idPersona, String tipoAuto) {
        super(placa, marca, modelo, idPersona);
        this.tipoAuto = tipoAuto;
    }

    // Getter
    public String getTipoAuto() {
        return tipoAuto;
    }

    // Setter
    public void setTipoAuto(String tipoAuto) {
        this.tipoAuto = tipoAuto;
    }

    // Representación textual
    @Override
    public String toString() {
        return "Carro{" +
               "idVehiculo=" + getIdVehiculo() +
               ", placa='" + getPlaca() + '\'' +
               ", marca='" + getMarca() + '\'' +
               ", modelo='" + getModelo() + '\'' +
               ", idPersona=" + getIdPersona() +
               ", tipoAuto='" + tipoAuto + '\'' +
               '}';
    }
}
