/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clasesjava;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Carlo
 */
class Zona {
    private String idZona;
    private String descripcion;
    private List<Espacio> espacios;
    
    public Zona(String idZona, String descripcion) {
        this.idZona = idZona;
        this.descripcion = descripcion;
        this.espacios = new ArrayList<>();
    }
    
    public Espacio buscarEspacioLibre() {
        System.out.println("Buscando espacio libre en zona: " + idZona);
        return null; 
    }
    
    public int calcularDisponibilidad() {
        int disponibles = 0;
        for (Espacio espacio : espacios) {
            if (!espacio.isOcupado()) {
                disponibles++;
            }
        }
        return disponibles;
    }
    
    public void liberarEspacio(String numeroEspacio) {
        System.out.println("Liberando espacio: " + numeroEspacio);
    }
    
    public String getIdZona() { 
        return idZona;
    }
    public void setIdZona(String idZona) {
        this.idZona = idZona;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public List<Espacio> getEspacios() {
        return espacios;
    }
    public void setEspacios(List<Espacio> espacios) { 
        this.espacios = espacios; 
    }
}
